﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;


public class LinkedList<T> : ILinkedList<T>
    where T:IComparable<T>
{
    private const int initialSize = 16;
    private int size { get; set; } =initialSize;

    private T[] data = new T[initialSize];
    private T this[int index] => this.data[index];
    public int Count { get; private set; } = 0;

    public void Add(T item)
    {
        this.data[this.Count] = item;

        this.Count++;
        if (this.Count>=this.size)
        {
            this.size *= 2;
        }
    }

    public bool Remove(T item)
    {
        bool result = false;

        for (int i = 0; i < this.Count; i++)
        {
            if (this[i].CompareTo(item)==0)
            {
                this.data = this.data.Take(i).Concat(this.data.Skip(i + 1)).ToArray();

                result = true;

                this.Count--;

                break;
            }
        }

        return result;
    }

    public IEnumerator<T> GetEnumerator()
    {
        for (int i = 0; i < this.Count; i++)
        {
            yield return this[i];
        }
    }


    IEnumerator IEnumerable.GetEnumerator()
    {
        return this.GetEnumerator();
    }
}


﻿using System;

[AttributeUsage(AttributeTargets.Field)]
public class RefreshEntitiesAttribute : Attribute
{
}
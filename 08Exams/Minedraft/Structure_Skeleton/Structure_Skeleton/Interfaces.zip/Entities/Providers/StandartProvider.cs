﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class StandartProvider : Provider
{
    public StandartProvider(int Id, double energyOutput) : base(Id, energyOutput)
    {
    }
}


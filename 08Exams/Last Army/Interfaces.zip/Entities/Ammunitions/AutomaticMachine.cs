﻿public class AutomaticMachine : Ammunition
{
    private const double weight = 6.3;

    public AutomaticMachine(string name)
        : base(name, weight)
    {
        this.WearLevel = this.Weight * 100;
    }
}
﻿
    public class MachineGun:Ammunition
    {
        private const double weight = 10.6;

        public MachineGun()
            : base(weight)
        {
        }
    }

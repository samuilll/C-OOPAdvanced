﻿using Ex02KingsGambit.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace Ex02KingsGambit.Entities
{
   public class RoyalGuard:Figure,IKillable
    {
        public RoyalGuard(string name) : base(name)
        {
            this.IsKilled=false;
        }

        public bool IsKilled { get; private set; }

        public override string AttackReaction => "is defending";

        public void KillTheFigure()
        {
            this.IsKilled = true;
        }
    }
}

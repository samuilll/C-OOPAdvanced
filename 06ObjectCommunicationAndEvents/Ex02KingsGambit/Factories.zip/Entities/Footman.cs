﻿using Ex02KingsGambit.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace Ex02KingsGambit.Entities
{
   public class Footman:Figure,IKillable
    {
        public Footman(string name) : base(name)
        {
            this.IsKilled = false;
        }

        public override string AttackReaction => "is panicking";

        public bool IsKilled { get; private set; }

        public void KillTheFigure()
        {
            this.IsKilled = true;
        }
    }
}

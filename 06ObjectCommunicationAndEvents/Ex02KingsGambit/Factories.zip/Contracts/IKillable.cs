﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex02KingsGambit.Contracts
{
    interface IKillable
    {
        bool IsKilled { get; }

        void KillTheFigure();
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex02KingsGambit.Contracts
{
  public  interface IRespondable:INameable
    {
        void Respond();
    }
}

﻿namespace Ex02KingsGambit.Commands
{
    public interface IExecutable
    {
        void Execute(string data);
    }
}
﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex02KingsGambit.Contracts
{
   public interface INameable
    {
        string Name { get; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex01EventImplementation
{
   public interface INameable
    {
        string Name { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;


public class Ruby:Gem
{
    public Ruby(Clarity clarity) : base(strength, agility, vitality,clarity)
    {

    }
    private const int strength = 7;
    private const int agility = 2;
    private const int vitality = 5;

}

﻿using System;
using System.Collections;
using System.Reflection;

class StartUp
{
    static void Main(string[] args)
    {
        Spy spy = new Spy();

        //  Console.WriteLine(spy.StealFieldInfo("Hacker","username","password"));
        // Console.WriteLine(spy.AnalyzeAcessModifiers("Hacker"));
        // Console.WriteLine(spy.RevealPrivateMethods("Hacker"));
        Console.WriteLine(spy.CollectGettersAndSetters("Hacker"));

    }
}




﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03BarracksFactory.Attributes
{
    [AttributeUsage(AttributeTargets.Field)]
   public class InjectAttribute:Attribute
    {
    }
}

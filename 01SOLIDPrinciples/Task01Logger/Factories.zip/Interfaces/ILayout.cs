﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task01Logger.Interfaces
{
   public interface ILayout
    {
        string GetInfo(IError error);

    }
}
// M/d
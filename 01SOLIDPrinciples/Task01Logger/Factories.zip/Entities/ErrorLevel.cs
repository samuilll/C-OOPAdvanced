﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task01Logger
{
   public enum ErrorLevel
    {
         INFO,
        WARNING,
        ERROR,
        CRITICAL,
        FATAL
    }
}
